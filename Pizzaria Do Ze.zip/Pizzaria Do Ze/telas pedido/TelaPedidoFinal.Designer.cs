﻿namespace Pizzaria_Do_Ze.Telas_Pedido
{
    partial class TelaPedidoFinal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.retiradaRadioBtn = new System.Windows.Forms.RadioButton();
            this.entregaRadiobtn = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.totalPedidoFinalLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cartaoRadioBtn = new System.Windows.Forms.RadioButton();
            this.pixRadioBtn = new System.Windows.Forms.RadioButton();
            this.dinheiroRadioBtn = new System.Windows.Forms.RadioButton();
            this.trocoTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.finalizarBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // retiradaRadioBtn
            // 
            this.retiradaRadioBtn.AutoSize = true;
            this.retiradaRadioBtn.Location = new System.Drawing.Point(116, 29);
            this.retiradaRadioBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.retiradaRadioBtn.Name = "retiradaRadioBtn";
            this.retiradaRadioBtn.Size = new System.Drawing.Size(95, 24);
            this.retiradaRadioBtn.TabIndex = 0;
            this.retiradaRadioBtn.TabStop = true;
            this.retiradaRadioBtn.Text = "Retirada";
            this.retiradaRadioBtn.UseVisualStyleBackColor = true;
            // 
            // entregaRadiobtn
            // 
            this.entregaRadiobtn.AutoSize = true;
            this.entregaRadiobtn.Location = new System.Drawing.Point(116, 57);
            this.entregaRadiobtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.entregaRadiobtn.Name = "entregaRadiobtn";
            this.entregaRadiobtn.Size = new System.Drawing.Size(91, 24);
            this.entregaRadiobtn.TabIndex = 1;
            this.entregaRadiobtn.TabStop = true;
            this.entregaRadiobtn.Text = "Entrega";
            this.entregaRadiobtn.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 42);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Entrega:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 193);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 29);
            this.label2.TabIndex = 3;
            this.label2.Text = "Total do pedido:";
            // 
            // totalPedidoFinalLabel
            // 
            this.totalPedidoFinalLabel.AutoSize = true;
            this.totalPedidoFinalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalPedidoFinalLabel.Location = new System.Drawing.Point(210, 193);
            this.totalPedidoFinalLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalPedidoFinalLabel.Name = "totalPedidoFinalLabel";
            this.totalPedidoFinalLabel.Size = new System.Drawing.Size(101, 29);
            this.totalPedidoFinalLabel.TabIndex = 4;
            this.totalPedidoFinalLabel.Text = "R$45,00";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 106);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(222, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Forma de pagamento:";
            // 
            // cartaoRadioBtn
            // 
            this.cartaoRadioBtn.AutoSize = true;
            this.cartaoRadioBtn.Location = new System.Drawing.Point(420, 108);
            this.cartaoRadioBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cartaoRadioBtn.Name = "cartaoRadioBtn";
            this.cartaoRadioBtn.Size = new System.Drawing.Size(82, 24);
            this.cartaoRadioBtn.TabIndex = 7;
            this.cartaoRadioBtn.TabStop = true;
            this.cartaoRadioBtn.Text = "Cartão";
            this.cartaoRadioBtn.UseVisualStyleBackColor = true;
            // 
            // pixRadioBtn
            // 
            this.pixRadioBtn.AutoSize = true;
            this.pixRadioBtn.Location = new System.Drawing.Point(251, 106);
            this.pixRadioBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pixRadioBtn.Name = "pixRadioBtn";
            this.pixRadioBtn.Size = new System.Drawing.Size(60, 24);
            this.pixRadioBtn.TabIndex = 8;
            this.pixRadioBtn.TabStop = true;
            this.pixRadioBtn.Text = "PIX";
            this.pixRadioBtn.UseVisualStyleBackColor = true;
            // 
            // dinheiroRadioBtn
            // 
            this.dinheiroRadioBtn.AutoSize = true;
            this.dinheiroRadioBtn.Location = new System.Drawing.Point(319, 106);
            this.dinheiroRadioBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dinheiroRadioBtn.Name = "dinheiroRadioBtn";
            this.dinheiroRadioBtn.Size = new System.Drawing.Size(93, 24);
            this.dinheiroRadioBtn.TabIndex = 9;
            this.dinheiroRadioBtn.TabStop = true;
            this.dinheiroRadioBtn.Text = "Dinheiro";
            this.dinheiroRadioBtn.UseVisualStyleBackColor = true;
            // 
            // trocoTextBox
            // 
            this.trocoTextBox.Location = new System.Drawing.Point(101, 145);
            this.trocoTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.trocoTextBox.Name = "trocoTextBox";
            this.trocoTextBox.Size = new System.Drawing.Size(210, 26);
            this.trocoTextBox.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 148);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "Troco para: ";
            // 
            // finalizarBtn
            // 
            this.finalizarBtn.Location = new System.Drawing.Point(495, 253);
            this.finalizarBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.finalizarBtn.Name = "finalizarBtn";
            this.finalizarBtn.Size = new System.Drawing.Size(123, 35);
            this.finalizarBtn.TabIndex = 12;
            this.finalizarBtn.Text = "Finalizar";
            this.finalizarBtn.UseVisualStyleBackColor = true;
            this.finalizarBtn.Click += new System.EventHandler(this.finalizarBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(360, 253);
            this.cancelBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(122, 35);
            this.cancelBtn.TabIndex = 13;
            this.cancelBtn.Text = "Cancelar";
            this.cancelBtn.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label4.Location = new System.Drawing.Point(231, 49);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(365, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "*Taxa fixa R$5,00 em pedidos abaixo de R$100,00";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.checkBox1.Location = new System.Drawing.Point(505, 95);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(86, 24);
            this.checkBox1.TabIndex = 14;
            this.checkBox1.Text = "Credito";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.checkBox2.Location = new System.Drawing.Point(505, 125);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(82, 24);
            this.checkBox2.TabIndex = 15;
            this.checkBox2.Text = "Debito";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // TelaPedidoFinal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(624, 293);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.finalizarBtn);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.trocoTextBox);
            this.Controls.Add(this.dinheiroRadioBtn);
            this.Controls.Add(this.pixRadioBtn);
            this.Controls.Add(this.cartaoRadioBtn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.totalPedidoFinalLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.entregaRadiobtn);
            this.Controls.Add(this.retiradaRadioBtn);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "TelaPedidoFinal";
            this.Text = "Pedido Final";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton retiradaRadioBtn;
        private System.Windows.Forms.RadioButton entregaRadiobtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label totalPedidoFinalLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton cartaoRadioBtn;
        private System.Windows.Forms.RadioButton pixRadioBtn;
        private System.Windows.Forms.RadioButton dinheiroRadioBtn;
        private System.Windows.Forms.TextBox trocoTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button finalizarBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
    }
}