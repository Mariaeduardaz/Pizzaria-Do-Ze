﻿namespace Pizzaria_Do_Ze.Telas_Pedido
{
    partial class TelaPedidoCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.nomeClienteLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tamanhoPizzaLabel = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.totalPagarLabel = new System.Windows.Forms.Label();
            this.addPizzaBtn = new System.Windows.Forms.Button();
            this.saboresPizzarListBox = new System.Windows.Forms.ListBox();
            this.seguinteBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.bebeidasComboBox = new System.Windows.Forms.ComboBox();
            this.addBebidaBtn = new System.Windows.Forms.Button();
            this.bebidaslistBox = new System.Windows.Forms.ListBox();
            this.excluirBebidaBtn = new System.Windows.Forms.Button();
            this.excluirPizzaBtn = new System.Windows.Forms.Button();
            this.retirarIngredienteBtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 38);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cliente: ";
            // 
            // nomeClienteLabel
            // 
            this.nomeClienteLabel.AutoSize = true;
            this.nomeClienteLabel.Location = new System.Drawing.Point(92, 38);
            this.nomeClienteLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nomeClienteLabel.Name = "nomeClienteLabel";
            this.nomeClienteLabel.Size = new System.Drawing.Size(126, 20);
            this.nomeClienteLabel.TabIndex = 1;
            this.nomeClienteLabel.Text = "Ana luiza Soccol";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 243);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Total a pagar: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 152);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Borda:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 111);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Sabores:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 71);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "Tamanho:";
            // 
            // tamanhoPizzaLabel
            // 
            this.tamanhoPizzaLabel.AutoSize = true;
            this.tamanhoPizzaLabel.Location = new System.Drawing.Point(92, 71);
            this.tamanhoPizzaLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tamanhoPizzaLabel.Name = "tamanhoPizzaLabel";
            this.tamanhoPizzaLabel.Size = new System.Drawing.Size(48, 20);
            this.tamanhoPizzaLabel.TabIndex = 6;
            this.tamanhoPizzaLabel.Text = "Broto";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(94, 108);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(180, 28);
            this.comboBox1.TabIndex = 7;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(92, 146);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(180, 28);
            this.comboBox2.TabIndex = 8;
            // 
            // totalPagarLabel
            // 
            this.totalPagarLabel.AutoSize = true;
            this.totalPagarLabel.Location = new System.Drawing.Point(134, 243);
            this.totalPagarLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalPagarLabel.Name = "totalPagarLabel";
            this.totalPagarLabel.Size = new System.Drawing.Size(74, 20);
            this.totalPagarLabel.TabIndex = 9;
            this.totalPagarLabel.Text = "R$ 40,00";
            // 
            // addPizzaBtn
            // 
            this.addPizzaBtn.Location = new System.Drawing.Point(282, 105);
            this.addPizzaBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.addPizzaBtn.Name = "addPizzaBtn";
            this.addPizzaBtn.Size = new System.Drawing.Size(111, 32);
            this.addPizzaBtn.TabIndex = 10;
            this.addPizzaBtn.Text = "Adicionar";
            this.addPizzaBtn.UseVisualStyleBackColor = true;
            // 
            // saboresPizzarListBox
            // 
            this.saboresPizzarListBox.FormattingEnabled = true;
            this.saboresPizzarListBox.ItemHeight = 20;
            this.saboresPizzarListBox.Location = new System.Drawing.Point(22, 283);
            this.saboresPizzarListBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.saboresPizzarListBox.Name = "saboresPizzarListBox";
            this.saboresPizzarListBox.Size = new System.Drawing.Size(218, 124);
            this.saboresPizzarListBox.TabIndex = 11;
            // 
            // seguinteBtn
            // 
            this.seguinteBtn.Location = new System.Drawing.Point(519, 487);
            this.seguinteBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.seguinteBtn.Name = "seguinteBtn";
            this.seguinteBtn.Size = new System.Drawing.Size(112, 35);
            this.seguinteBtn.TabIndex = 12;
            this.seguinteBtn.Text = "Seguinte";
            this.seguinteBtn.UseVisualStyleBackColor = true;
            this.seguinteBtn.Click += new System.EventHandler(this.seguinteBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(399, 487);
            this.cancelBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(112, 35);
            this.cancelBtn.TabIndex = 13;
            this.cancelBtn.Text = "Cancelar";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 190);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 20);
            this.label6.TabIndex = 14;
            this.label6.Text = "Bebida:";
            // 
            // bebeidasComboBox
            // 
            this.bebeidasComboBox.FormattingEnabled = true;
            this.bebeidasComboBox.Location = new System.Drawing.Point(92, 187);
            this.bebeidasComboBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bebeidasComboBox.Name = "bebeidasComboBox";
            this.bebeidasComboBox.Size = new System.Drawing.Size(180, 28);
            this.bebeidasComboBox.TabIndex = 15;
            // 
            // addBebidaBtn
            // 
            this.addBebidaBtn.Location = new System.Drawing.Point(280, 183);
            this.addBebidaBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.addBebidaBtn.Name = "addBebidaBtn";
            this.addBebidaBtn.Size = new System.Drawing.Size(113, 32);
            this.addBebidaBtn.TabIndex = 16;
            this.addBebidaBtn.Text = "Adicionar";
            this.addBebidaBtn.UseVisualStyleBackColor = true;
            // 
            // bebidaslistBox
            // 
            this.bebidaslistBox.FormattingEnabled = true;
            this.bebidaslistBox.ItemHeight = 20;
            this.bebidaslistBox.Location = new System.Drawing.Point(262, 283);
            this.bebidaslistBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bebidaslistBox.Name = "bebidaslistBox";
            this.bebidaslistBox.Size = new System.Drawing.Size(239, 124);
            this.bebidaslistBox.TabIndex = 17;
            // 
            // excluirBebidaBtn
            // 
            this.excluirBebidaBtn.Location = new System.Drawing.Point(262, 417);
            this.excluirBebidaBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.excluirBebidaBtn.Name = "excluirBebidaBtn";
            this.excluirBebidaBtn.Size = new System.Drawing.Size(112, 35);
            this.excluirBebidaBtn.TabIndex = 18;
            this.excluirBebidaBtn.Text = "Adicionar";
            this.excluirBebidaBtn.UseVisualStyleBackColor = true;
            // 
            // excluirPizzaBtn
            // 
            this.excluirPizzaBtn.Location = new System.Drawing.Point(389, 417);
            this.excluirPizzaBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.excluirPizzaBtn.Name = "excluirPizzaBtn";
            this.excluirPizzaBtn.Size = new System.Drawing.Size(112, 35);
            this.excluirPizzaBtn.TabIndex = 19;
            this.excluirPizzaBtn.Text = "Excluir selecionado";
            this.excluirPizzaBtn.UseVisualStyleBackColor = true;
            // 
            // retirarIngredienteBtn
            // 
            this.retirarIngredienteBtn.Location = new System.Drawing.Point(13, 417);
            this.retirarIngredienteBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.retirarIngredienteBtn.Name = "retirarIngredienteBtn";
            this.retirarIngredienteBtn.Size = new System.Drawing.Size(227, 35);
            this.retirarIngredienteBtn.TabIndex = 20;
            this.retirarIngredienteBtn.Text = "Retirar algum ingrediente";
            this.retirarIngredienteBtn.UseVisualStyleBackColor = true;
            this.retirarIngredienteBtn.Click += new System.EventHandler(this.retirarIngredienteBtn_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(282, 146);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 32);
            this.button1.TabIndex = 21;
            this.button1.Text = "Adicionar";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // TelaPedidoCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(656, 541);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.retirarIngredienteBtn);
            this.Controls.Add(this.excluirPizzaBtn);
            this.Controls.Add(this.excluirBebidaBtn);
            this.Controls.Add(this.bebidaslistBox);
            this.Controls.Add(this.addBebidaBtn);
            this.Controls.Add(this.bebeidasComboBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.seguinteBtn);
            this.Controls.Add(this.saboresPizzarListBox);
            this.Controls.Add(this.addPizzaBtn);
            this.Controls.Add(this.totalPagarLabel);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.tamanhoPizzaLabel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nomeClienteLabel);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "TelaPedidoCliente";
            this.Text = "TelaPedidoCliente";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label nomeClienteLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label tamanhoPizzaLabel;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label totalPagarLabel;
        private System.Windows.Forms.Button addPizzaBtn;
        private System.Windows.Forms.ListBox saboresPizzarListBox;
        private System.Windows.Forms.Button seguinteBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox bebeidasComboBox;
        private System.Windows.Forms.Button addBebidaBtn;
        private System.Windows.Forms.ListBox bebidaslistBox;
        private System.Windows.Forms.Button excluirBebidaBtn;
        private System.Windows.Forms.Button excluirPizzaBtn;
        private System.Windows.Forms.Button retirarIngredienteBtn;
        private System.Windows.Forms.Button button1;
    }
}