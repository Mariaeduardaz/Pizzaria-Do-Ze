﻿namespace Pizzaria_Do_Ze.Telas_Pedido
{
    partial class TelaPedidoSelecionado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label10 = new System.Windows.Forms.Label();
            this.pagamentoLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.endereoLabel = new System.Windows.Forms.Label();
            this.pedidoLabel = new System.Windows.Forms.Label();
            this.statusPedidoLabel = new System.Windows.Forms.Label();
            this.idPedidoLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.fecharBtn = new System.Windows.Forms.Button();
            this.entregadorResponsavelLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.valorLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(39, 282);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 20);
            this.label10.TabIndex = 22;
            this.label10.Text = "Valor: ";
            // 
            // pagamentoLabel
            // 
            this.pagamentoLabel.AutoSize = true;
            this.pagamentoLabel.Location = new System.Drawing.Point(113, 213);
            this.pagamentoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pagamentoLabel.Name = "pagamentoLabel";
            this.pagamentoLabel.Size = new System.Drawing.Size(121, 20);
            this.pagamentoLabel.TabIndex = 21;
            this.pagamentoLabel.Text = "Cartão - Credito";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 213);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 20);
            this.label8.TabIndex = 20;
            this.label8.Text = "Pagamento:";
            // 
            // endereoLabel
            // 
            this.endereoLabel.AutoSize = true;
            this.endereoLabel.Location = new System.Drawing.Point(113, 249);
            this.endereoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.endereoLabel.Name = "endereoLabel";
            this.endereoLabel.Size = new System.Drawing.Size(234, 20);
            this.endereoLabel.TabIndex = 19;
            this.endereoLabel.Text = "Rua Virgilio Godinho 543 centro";
            // 
            // pedidoLabel
            // 
            this.pedidoLabel.AutoSize = true;
            this.pedidoLabel.Location = new System.Drawing.Point(113, 173);
            this.pedidoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pedidoLabel.Name = "pedidoLabel";
            this.pedidoLabel.Size = new System.Drawing.Size(288, 20);
            this.pedidoLabel.TabIndex = 18;
            this.pedidoLabel.Text = "Pizza broto, chocolate, coca-cola 600ml";
            // 
            // statusPedidoLabel
            // 
            this.statusPedidoLabel.AutoSize = true;
            this.statusPedidoLabel.Location = new System.Drawing.Point(113, 96);
            this.statusPedidoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.statusPedidoLabel.Name = "statusPedidoLabel";
            this.statusPedidoLabel.Size = new System.Drawing.Size(140, 20);
            this.statusPedidoLabel.TabIndex = 17;
            this.statusPedidoLabel.Text = "Entregue as 21:30";
            // 
            // idPedidoLabel
            // 
            this.idPedidoLabel.AutoSize = true;
            this.idPedidoLabel.Location = new System.Drawing.Point(113, 56);
            this.idPedidoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.idPedidoLabel.Name = "idPedidoLabel";
            this.idPedidoLabel.Size = new System.Drawing.Size(81, 20);
            this.idPedidoLabel.TabIndex = 16;
            this.idPedidoLabel.Text = "#8732973";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 249);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 20);
            this.label4.TabIndex = 15;
            this.label4.Text = "Endereço: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(39, 173);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 20);
            this.label3.TabIndex = 14;
            this.label3.Text = "Pedido: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 96);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "Status:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(-3, 56);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "ID do pedido: ";
            // 
            // fecharBtn
            // 
            this.fecharBtn.Location = new System.Drawing.Point(332, 310);
            this.fecharBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.fecharBtn.Name = "fecharBtn";
            this.fecharBtn.Size = new System.Drawing.Size(112, 35);
            this.fecharBtn.TabIndex = 25;
            this.fecharBtn.Text = "Fechar";
            this.fecharBtn.UseVisualStyleBackColor = true;
            this.fecharBtn.Click += new System.EventHandler(this.fecharBtn_Click);
            // 
            // entregadorResponsavelLabel
            // 
            this.entregadorResponsavelLabel.AutoSize = true;
            this.entregadorResponsavelLabel.Location = new System.Drawing.Point(113, 137);
            this.entregadorResponsavelLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.entregadorResponsavelLabel.Name = "entregadorResponsavelLabel";
            this.entregadorResponsavelLabel.Size = new System.Drawing.Size(38, 20);
            this.entregadorResponsavelLabel.TabIndex = 26;
            this.entregadorResponsavelLabel.Text = "Luiz";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(64, 137);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 20);
            this.label6.TabIndex = 27;
            this.label6.Text = "Por: ";
            // 
            // valorLabel
            // 
            this.valorLabel.AutoSize = true;
            this.valorLabel.Location = new System.Drawing.Point(101, 282);
            this.valorLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.valorLabel.Name = "valorLabel";
            this.valorLabel.Size = new System.Drawing.Size(70, 20);
            this.valorLabel.TabIndex = 28;
            this.valorLabel.Text = "R$45,00";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(24, 19);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(170, 20);
            this.label5.TabIndex = 29;
            this.label5.Text = "Detalhes do pedido:";
            // 
            // TelaPedidoSelecionado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(446, 346);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.valorLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.entregadorResponsavelLabel);
            this.Controls.Add(this.fecharBtn);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.pagamentoLabel);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.endereoLabel);
            this.Controls.Add(this.pedidoLabel);
            this.Controls.Add(this.statusPedidoLabel);
            this.Controls.Add(this.idPedidoLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "TelaPedidoSelecionado";
            this.Text = "Pedido Entregue";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label pagamentoLabel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label endereoLabel;
        private System.Windows.Forms.Label pedidoLabel;
        private System.Windows.Forms.Label statusPedidoLabel;
        private System.Windows.Forms.Label idPedidoLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button fecharBtn;
        private System.Windows.Forms.Label entregadorResponsavelLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label valorLabel;
        private System.Windows.Forms.Label label5;
    }
}