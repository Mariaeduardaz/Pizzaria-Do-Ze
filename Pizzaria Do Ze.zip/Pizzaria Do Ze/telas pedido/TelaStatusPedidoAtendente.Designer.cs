﻿namespace Pizzaria_Do_Ze.Telas_Pedido
{
    partial class TelaStatusPedidoAtendente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pagoRadioBtn = new System.Windows.Forms.RadioButton();
            this.pendenteRadioBtn = new System.Windows.Forms.RadioButton();
            this.preparoRadioBtn = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.idPedidoLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 94);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Status do pagamento:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 206);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(165, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Status do pedido:";
            // 
            // pagoRadioBtn
            // 
            this.pagoRadioBtn.AutoSize = true;
            this.pagoRadioBtn.Location = new System.Drawing.Point(215, 78);
            this.pagoRadioBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pagoRadioBtn.Name = "pagoRadioBtn";
            this.pagoRadioBtn.Size = new System.Drawing.Size(71, 24);
            this.pagoRadioBtn.TabIndex = 3;
            this.pagoRadioBtn.TabStop = true;
            this.pagoRadioBtn.Text = "Pago";
            this.pagoRadioBtn.UseVisualStyleBackColor = true;
            // 
            // pendenteRadioBtn
            // 
            this.pendenteRadioBtn.AutoSize = true;
            this.pendenteRadioBtn.Location = new System.Drawing.Point(215, 112);
            this.pendenteRadioBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pendenteRadioBtn.Name = "pendenteRadioBtn";
            this.pendenteRadioBtn.Size = new System.Drawing.Size(103, 24);
            this.pendenteRadioBtn.TabIndex = 4;
            this.pendenteRadioBtn.TabStop = true;
            this.pendenteRadioBtn.Text = "Pendente";
            this.pendenteRadioBtn.UseVisualStyleBackColor = true;
            // 
            // preparoRadioBtn
            // 
            this.preparoRadioBtn.AutoSize = true;
            this.preparoRadioBtn.Location = new System.Drawing.Point(186, 188);
            this.preparoRadioBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.preparoRadioBtn.Name = "preparoRadioBtn";
            this.preparoRadioBtn.Size = new System.Drawing.Size(117, 24);
            this.preparoRadioBtn.TabIndex = 5;
            this.preparoRadioBtn.TabStop = true;
            this.preparoRadioBtn.Text = "Em preparo";
            this.preparoRadioBtn.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(186, 222);
            this.radioButton4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(95, 24);
            this.radioButton4.TabIndex = 6;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Retirada";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(186, 256);
            this.radioButton5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(161, 24);
            this.radioButton5.TabIndex = 7;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Saiu para entrega";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(276, 374);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 40);
            this.button1.TabIndex = 8;
            this.button1.Text = "Fechar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 29);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 25);
            this.label3.TabIndex = 9;
            this.label3.Text = "ID Pedido:";
            // 
            // idPedidoLabel
            // 
            this.idPedidoLabel.AutoSize = true;
            this.idPedidoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idPedidoLabel.Location = new System.Drawing.Point(124, 29);
            this.idPedidoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.idPedidoLabel.Name = "idPedidoLabel";
            this.idPedidoLabel.Size = new System.Drawing.Size(100, 25);
            this.idPedidoLabel.TabIndex = 10;
            this.idPedidoLabel.Text = "#9901011";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 324);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 22);
            this.label4.TabIndex = 11;
            this.label4.Text = "Entregador: ";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(123, 323);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(180, 28);
            this.comboBox1.TabIndex = 12;
            // 
            // TelaStatusPedidoAtendente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(403, 417);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.idPedidoLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.radioButton5);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.preparoRadioBtn);
            this.Controls.Add(this.pendenteRadioBtn);
            this.Controls.Add(this.pagoRadioBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "TelaStatusPedidoAtendente";
            this.Text = "Status Atendente";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton pagoRadioBtn;
        private System.Windows.Forms.RadioButton pendenteRadioBtn;
        private System.Windows.Forms.RadioButton preparoRadioBtn;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label idPedidoLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}