﻿namespace Pizzaria_Do_Ze.Telas_Pedido
{
    partial class TelaAcessarStatusPedidoAtendente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.idPedidosAbertoscomboBox = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.acessarBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(110, 108);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID:";
            // 
            // idPedidosAbertoscomboBox
            // 
            this.idPedidosAbertoscomboBox.FormattingEnabled = true;
            this.idPedidosAbertoscomboBox.Location = new System.Drawing.Point(148, 100);
            this.idPedidosAbertoscomboBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.idPedidosAbertoscomboBox.Name = "idPedidosAbertoscomboBox";
            this.idPedidosAbertoscomboBox.Size = new System.Drawing.Size(180, 28);
            this.idPedidosAbertoscomboBox.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(376, 155);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 35);
            this.button1.TabIndex = 2;
            this.button1.Text = "Fechar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // acessarBtn
            // 
            this.acessarBtn.Location = new System.Drawing.Point(336, 96);
            this.acessarBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.acessarBtn.Name = "acessarBtn";
            this.acessarBtn.Size = new System.Drawing.Size(112, 35);
            this.acessarBtn.TabIndex = 3;
            this.acessarBtn.Text = "Acessar";
            this.acessarBtn.UseVisualStyleBackColor = true;
            this.acessarBtn.Click += new System.EventHandler(this.acessarBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(85, 62);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nome:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(147, 62);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(170, 26);
            this.textBox1.TabIndex = 5;
            // 
            // TelaAcessarStatusPedidoAtendente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(501, 211);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.acessarBtn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.idPedidosAbertoscomboBox);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "TelaAcessarStatusPedidoAtendente";
            this.Text = "Acessar Status Atendente";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox idPedidosAbertoscomboBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button acessarBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
    }
}