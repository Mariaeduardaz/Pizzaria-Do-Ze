﻿namespace Pizzaria_Do_Ze.Telas_cadastros
{
    partial class TelaCadastroCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameTextBot = new System.Windows.Forms.TextBox();
            this.TelefoneMaskTB = new System.Windows.Forms.MaskedTextBox();
            this.EmailTextBox = new System.Windows.Forms.TextBox();
            this.enderecoTextBox = new System.Windows.Forms.TextBox();
            this.complementoTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cadastrarBtn = new System.Windows.Forms.Button();
            this.voltarBtn = new System.Windows.Forms.Button();
            this.CPFMaskedTB = new System.Windows.Forms.MaskedTextBox();
            this.CEPMaskedTB = new System.Windows.Forms.MaskedTextBox();
            this.clienteCadastradoBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameTextBot
            // 
            this.nameTextBot.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameTextBot.Location = new System.Drawing.Point(90, 38);
            this.nameTextBot.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.nameTextBot.Name = "nameTextBot";
            this.nameTextBot.Size = new System.Drawing.Size(332, 33);
            this.nameTextBot.TabIndex = 0;
            // 
            // TelefoneMaskTB
            // 
            this.TelefoneMaskTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TelefoneMaskTB.Location = new System.Drawing.Point(90, 125);
            this.TelefoneMaskTB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TelefoneMaskTB.Mask = "(99) 0000-0000";
            this.TelefoneMaskTB.Name = "TelefoneMaskTB";
            this.TelefoneMaskTB.Size = new System.Drawing.Size(206, 33);
            this.TelefoneMaskTB.TabIndex = 1;
            // 
            // EmailTextBox
            // 
            this.EmailTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailTextBox.Location = new System.Drawing.Point(90, 82);
            this.EmailTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.EmailTextBox.Name = "EmailTextBox";
            this.EmailTextBox.Size = new System.Drawing.Size(355, 33);
            this.EmailTextBox.TabIndex = 2;
            // 
            // enderecoTextBox
            // 
            this.enderecoTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enderecoTextBox.Location = new System.Drawing.Point(90, 270);
            this.enderecoTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.enderecoTextBox.Name = "enderecoTextBox";
            this.enderecoTextBox.Size = new System.Drawing.Size(355, 33);
            this.enderecoTextBox.TabIndex = 5;
            // 
            // complementoTextBox
            // 
            this.complementoTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.complementoTextBox.Location = new System.Drawing.Point(90, 313);
            this.complementoTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.complementoTextBox.Name = "complementoTextBox";
            this.complementoTextBox.Size = new System.Drawing.Size(355, 33);
            this.complementoTextBox.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 48);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "Nome:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 125);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Telefone:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 82);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "E-mail:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(37, 180);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "CPF:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(37, 233);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "CEP:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(0, 270);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "Endereço:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(43, 323);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 20);
            this.label7.TabIndex = 13;
            this.label7.Text = "obs:";
            // 
            // cadastrarBtn
            // 
            this.cadastrarBtn.Location = new System.Drawing.Point(371, 356);
            this.cadastrarBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cadastrarBtn.Name = "cadastrarBtn";
            this.cadastrarBtn.Size = new System.Drawing.Size(130, 30);
            this.cadastrarBtn.TabIndex = 14;
            this.cadastrarBtn.Text = "Cadastrar";
            this.cadastrarBtn.UseVisualStyleBackColor = true;
            this.cadastrarBtn.Click += new System.EventHandler(this.cadastrarBtn_Click);
            // 
            // voltarBtn
            // 
            this.voltarBtn.Location = new System.Drawing.Point(450, 396);
            this.voltarBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.voltarBtn.Name = "voltarBtn";
            this.voltarBtn.Size = new System.Drawing.Size(134, 43);
            this.voltarBtn.TabIndex = 15;
            this.voltarBtn.Text = "Voltar";
            this.voltarBtn.UseVisualStyleBackColor = true;
            this.voltarBtn.Click += new System.EventHandler(this.voltarBtn_Click);
            // 
            // CPFMaskedTB
            // 
            this.CPFMaskedTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CPFMaskedTB.Location = new System.Drawing.Point(90, 180);
            this.CPFMaskedTB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CPFMaskedTB.Mask = "000.000.000-00";
            this.CPFMaskedTB.Name = "CPFMaskedTB";
            this.CPFMaskedTB.Size = new System.Drawing.Size(206, 33);
            this.CPFMaskedTB.TabIndex = 16;
            // 
            // CEPMaskedTB
            // 
            this.CEPMaskedTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CEPMaskedTB.Location = new System.Drawing.Point(90, 223);
            this.CEPMaskedTB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CEPMaskedTB.Mask = "00000-000";
            this.CEPMaskedTB.Name = "CEPMaskedTB";
            this.CEPMaskedTB.Size = new System.Drawing.Size(206, 33);
            this.CEPMaskedTB.TabIndex = 17;
            // 
            // clienteCadastradoBtn
            // 
            this.clienteCadastradoBtn.Location = new System.Drawing.Point(229, 356);
            this.clienteCadastradoBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.clienteCadastradoBtn.Name = "clienteCadastradoBtn";
            this.clienteCadastradoBtn.Size = new System.Drawing.Size(134, 30);
            this.clienteCadastradoBtn.TabIndex = 18;
            this.clienteCadastradoBtn.Text = "Cadastrado";
            this.clienteCadastradoBtn.UseVisualStyleBackColor = true;
            // 
            // TelaCadastroCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(590, 445);
            this.Controls.Add(this.clienteCadastradoBtn);
            this.Controls.Add(this.CEPMaskedTB);
            this.Controls.Add(this.CPFMaskedTB);
            this.Controls.Add(this.voltarBtn);
            this.Controls.Add(this.cadastrarBtn);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.complementoTextBox);
            this.Controls.Add(this.enderecoTextBox);
            this.Controls.Add(this.EmailTextBox);
            this.Controls.Add(this.TelefoneMaskTB);
            this.Controls.Add(this.nameTextBot);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "TelaCadastroCliente";
            this.Text = "Cadastro Cliente";
            this.Load += new System.EventHandler(this.TelaCadastroCliente_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameTextBot;
        private System.Windows.Forms.MaskedTextBox TelefoneMaskTB;
        private System.Windows.Forms.TextBox EmailTextBox;
        private System.Windows.Forms.TextBox enderecoTextBox;
        private System.Windows.Forms.TextBox complementoTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button cadastrarBtn;
        private System.Windows.Forms.Button voltarBtn;
        private System.Windows.Forms.MaskedTextBox CPFMaskedTB;
        private System.Windows.Forms.MaskedTextBox CEPMaskedTB;
        private System.Windows.Forms.Button clienteCadastradoBtn;
    }
}