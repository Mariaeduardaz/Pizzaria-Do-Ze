﻿namespace Pizzaria_Do_Ze.Telas_Admin
{
    partial class TelaEditSabores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.nomePizzaTextBox = new System.Windows.Forms.TextBox();
            this.ingredientesComboBox = new System.Windows.Forms.ComboBox();
            this.addBtn = new System.Windows.Forms.Button();
            this.saboresEscolhidosListBox = new System.Windows.Forms.ListBox();
            this.especialCheckBox = new System.Windows.Forms.CheckBox();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.cadastrarBtn = new System.Windows.Forms.Button();
            this.excluirSaborBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome da pizza:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 74);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ingredientes: ";
            // 
            // nomePizzaTextBox
            // 
            this.nomePizzaTextBox.Location = new System.Drawing.Point(139, 29);
            this.nomePizzaTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.nomePizzaTextBox.Name = "nomePizzaTextBox";
            this.nomePizzaTextBox.Size = new System.Drawing.Size(246, 26);
            this.nomePizzaTextBox.TabIndex = 2;
            // 
            // ingredientesComboBox
            // 
            this.ingredientesComboBox.FormattingEnabled = true;
            this.ingredientesComboBox.Location = new System.Drawing.Point(139, 74);
            this.ingredientesComboBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ingredientesComboBox.Name = "ingredientesComboBox";
            this.ingredientesComboBox.Size = new System.Drawing.Size(246, 28);
            this.ingredientesComboBox.TabIndex = 3;
            // 
            // addBtn
            // 
            this.addBtn.Location = new System.Drawing.Point(393, 74);
            this.addBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(103, 28);
            this.addBtn.TabIndex = 4;
            this.addBtn.Text = "Adicionar";
            this.addBtn.UseVisualStyleBackColor = true;
            // 
            // saboresEscolhidosListBox
            // 
            this.saboresEscolhidosListBox.FormattingEnabled = true;
            this.saboresEscolhidosListBox.ItemHeight = 20;
            this.saboresEscolhidosListBox.Location = new System.Drawing.Point(17, 122);
            this.saboresEscolhidosListBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.saboresEscolhidosListBox.Name = "saboresEscolhidosListBox";
            this.saboresEscolhidosListBox.Size = new System.Drawing.Size(535, 224);
            this.saboresEscolhidosListBox.TabIndex = 5;
            // 
            // especialCheckBox
            // 
            this.especialCheckBox.AutoSize = true;
            this.especialCheckBox.Location = new System.Drawing.Point(393, 29);
            this.especialCheckBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.especialCheckBox.Name = "especialCheckBox";
            this.especialCheckBox.Size = new System.Drawing.Size(142, 24);
            this.especialCheckBox.TabIndex = 6;
            this.especialCheckBox.Text = "Sabor Especial";
            this.especialCheckBox.UseVisualStyleBackColor = true;
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(350, 378);
            this.cancelBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(104, 32);
            this.cancelBtn.TabIndex = 7;
            this.cancelBtn.Text = "Cancelar";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // cadastrarBtn
            // 
            this.cadastrarBtn.Location = new System.Drawing.Point(462, 378);
            this.cadastrarBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cadastrarBtn.Name = "cadastrarBtn";
            this.cadastrarBtn.Size = new System.Drawing.Size(102, 32);
            this.cadastrarBtn.TabIndex = 8;
            this.cadastrarBtn.Text = "Cadastrar";
            this.cadastrarBtn.UseVisualStyleBackColor = true;
            this.cadastrarBtn.Click += new System.EventHandler(this.cadastrarBtn_Click);
            // 
            // excluirSaborBtn
            // 
            this.excluirSaborBtn.Location = new System.Drawing.Point(384, 311);
            this.excluirSaborBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.excluirSaborBtn.Name = "excluirSaborBtn";
            this.excluirSaborBtn.Size = new System.Drawing.Size(168, 35);
            this.excluirSaborBtn.TabIndex = 9;
            this.excluirSaborBtn.Text = "Excluir";
            this.excluirSaborBtn.UseVisualStyleBackColor = true;
            // 
            // TelaEditSabores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(565, 413);
            this.Controls.Add(this.excluirSaborBtn);
            this.Controls.Add(this.cadastrarBtn);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.especialCheckBox);
            this.Controls.Add(this.saboresEscolhidosListBox);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.ingredientesComboBox);
            this.Controls.Add(this.nomePizzaTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "TelaEditSabores";
            this.Text = "Editar Sabor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox nomePizzaTextBox;
        private System.Windows.Forms.ComboBox ingredientesComboBox;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.ListBox saboresEscolhidosListBox;
        private System.Windows.Forms.CheckBox especialCheckBox;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.Button cadastrarBtn;
        private System.Windows.Forms.Button excluirSaborBtn;
    }
}