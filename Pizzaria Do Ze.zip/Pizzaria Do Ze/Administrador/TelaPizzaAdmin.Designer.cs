﻿namespace Pizzaria_Do_Ze.Telas_Cadastrais
{
    partial class TelaPizzaAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.saboresBtn = new System.Windows.Forms.Button();
            this.valoresBtn = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // saboresBtn
            // 
            this.saboresBtn.Location = new System.Drawing.Point(89, 116);
            this.saboresBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.saboresBtn.Name = "saboresBtn";
            this.saboresBtn.Size = new System.Drawing.Size(213, 68);
            this.saboresBtn.TabIndex = 0;
            this.saboresBtn.Text = "Sabor";
            this.saboresBtn.UseVisualStyleBackColor = true;
            this.saboresBtn.Click += new System.EventHandler(this.saboresBtn_Click);
            // 
            // valoresBtn
            // 
            this.valoresBtn.Location = new System.Drawing.Point(89, 38);
            this.valoresBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.valoresBtn.Name = "valoresBtn";
            this.valoresBtn.Size = new System.Drawing.Size(213, 68);
            this.valoresBtn.TabIndex = 1;
            this.valoresBtn.Text = "Ingrendiente";
            this.valoresBtn.UseVisualStyleBackColor = true;
            this.valoresBtn.Click += new System.EventHandler(this.valoresBtn_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(308, 207);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(106, 30);
            this.button3.TabIndex = 2;
            this.button3.Text = "Voltar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // TelaPizzaAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(422, 244);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.valoresBtn);
            this.Controls.Add(this.saboresBtn);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "TelaPizzaAdmin";
            this.Text = "Administrador";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button saboresBtn;
        private System.Windows.Forms.Button valoresBtn;
        private System.Windows.Forms.Button button3;
    }
}