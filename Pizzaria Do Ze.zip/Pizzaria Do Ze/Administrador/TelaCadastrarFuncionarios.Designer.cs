﻿namespace Pizzaria_Do_Ze.Telas_Cadastrais
{
    partial class TelaCadastrarFuncionarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.nomeTB = new System.Windows.Forms.TextBox();
            this.matriculaTB = new System.Windows.Forms.TextBox();
            this.cpfMaskedTB = new System.Windows.Forms.MaskedTextBox();
            this.telefonemaskedTB = new System.Windows.Forms.MaskedTextBox();
            this.senhaMaskedTB = new System.Windows.Forms.MaskedTextBox();
            this.adminRadioBtn = new System.Windows.Forms.RadioButton();
            this.AtendenteRadioBtn = new System.Windows.Forms.RadioButton();
            this.entregadorRadioBtn = new System.Windows.Forms.RadioButton();
            this.cnhMaskedTB = new System.Windows.Forms.MaskedTextBox();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.cadastrarBtn = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.validadeCNHdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 76);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "CPF:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 112);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Telefone:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 151);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Matricula:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 194);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Senha:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 263);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Grupo:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 352);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "CNH:";
            // 
            // nomeTB
            // 
            this.nomeTB.Location = new System.Drawing.Point(144, 29);
            this.nomeTB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.nomeTB.Name = "nomeTB";
            this.nomeTB.Size = new System.Drawing.Size(148, 26);
            this.nomeTB.TabIndex = 8;
            // 
            // matriculaTB
            // 
            this.matriculaTB.Location = new System.Drawing.Point(144, 149);
            this.matriculaTB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.matriculaTB.Name = "matriculaTB";
            this.matriculaTB.Size = new System.Drawing.Size(148, 26);
            this.matriculaTB.TabIndex = 11;
            // 
            // cpfMaskedTB
            // 
            this.cpfMaskedTB.Location = new System.Drawing.Point(144, 69);
            this.cpfMaskedTB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cpfMaskedTB.Name = "cpfMaskedTB";
            this.cpfMaskedTB.Size = new System.Drawing.Size(148, 26);
            this.cpfMaskedTB.TabIndex = 12;
            // 
            // telefonemaskedTB
            // 
            this.telefonemaskedTB.Location = new System.Drawing.Point(144, 109);
            this.telefonemaskedTB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.telefonemaskedTB.Name = "telefonemaskedTB";
            this.telefonemaskedTB.Size = new System.Drawing.Size(148, 26);
            this.telefonemaskedTB.TabIndex = 13;
            // 
            // senhaMaskedTB
            // 
            this.senhaMaskedTB.Location = new System.Drawing.Point(144, 194);
            this.senhaMaskedTB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.senhaMaskedTB.Name = "senhaMaskedTB";
            this.senhaMaskedTB.PasswordChar = '*';
            this.senhaMaskedTB.Size = new System.Drawing.Size(148, 26);
            this.senhaMaskedTB.TabIndex = 14;
            // 
            // adminRadioBtn
            // 
            this.adminRadioBtn.AutoSize = true;
            this.adminRadioBtn.Location = new System.Drawing.Point(144, 234);
            this.adminRadioBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.adminRadioBtn.Name = "adminRadioBtn";
            this.adminRadioBtn.Size = new System.Drawing.Size(79, 24);
            this.adminRadioBtn.TabIndex = 15;
            this.adminRadioBtn.TabStop = true;
            this.adminRadioBtn.Text = "Admin";
            this.adminRadioBtn.UseVisualStyleBackColor = true;
            // 
            // AtendenteRadioBtn
            // 
            this.AtendenteRadioBtn.AutoSize = true;
            this.AtendenteRadioBtn.Location = new System.Drawing.Point(144, 274);
            this.AtendenteRadioBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.AtendenteRadioBtn.Name = "AtendenteRadioBtn";
            this.AtendenteRadioBtn.Size = new System.Drawing.Size(109, 24);
            this.AtendenteRadioBtn.TabIndex = 16;
            this.AtendenteRadioBtn.TabStop = true;
            this.AtendenteRadioBtn.Text = "Atendente";
            this.AtendenteRadioBtn.UseVisualStyleBackColor = true;
            // 
            // entregadorRadioBtn
            // 
            this.entregadorRadioBtn.AutoSize = true;
            this.entregadorRadioBtn.Location = new System.Drawing.Point(144, 309);
            this.entregadorRadioBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.entregadorRadioBtn.Name = "entregadorRadioBtn";
            this.entregadorRadioBtn.Size = new System.Drawing.Size(114, 24);
            this.entregadorRadioBtn.TabIndex = 17;
            this.entregadorRadioBtn.TabStop = true;
            this.entregadorRadioBtn.Text = "Entregador";
            this.entregadorRadioBtn.UseVisualStyleBackColor = true;
            // 
            // cnhMaskedTB
            // 
            this.cnhMaskedTB.Location = new System.Drawing.Point(144, 348);
            this.cnhMaskedTB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cnhMaskedTB.Name = "cnhMaskedTB";
            this.cnhMaskedTB.Size = new System.Drawing.Size(148, 26);
            this.cnhMaskedTB.TabIndex = 18;
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(278, 489);
            this.cancelBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(112, 35);
            this.cancelBtn.TabIndex = 20;
            this.cancelBtn.Text = "Cancelar";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // cadastrarBtn
            // 
            this.cadastrarBtn.Location = new System.Drawing.Point(398, 489);
            this.cadastrarBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cadastrarBtn.Name = "cadastrarBtn";
            this.cadastrarBtn.Size = new System.Drawing.Size(112, 35);
            this.cadastrarBtn.TabIndex = 21;
            this.cadastrarBtn.Text = "Cadastrar";
            this.cadastrarBtn.UseVisualStyleBackColor = true;
            this.cadastrarBtn.Click += new System.EventHandler(this.cadastrarBtn_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 400);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "Validade CNH:";
            // 
            // validadeCNHdateTimePicker
            // 
            this.validadeCNHdateTimePicker.Location = new System.Drawing.Point(145, 400);
            this.validadeCNHdateTimePicker.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.validadeCNHdateTimePicker.Name = "validadeCNHdateTimePicker";
            this.validadeCNHdateTimePicker.Size = new System.Drawing.Size(298, 26);
            this.validadeCNHdateTimePicker.TabIndex = 19;
            // 
            // TelaCadastrarFuncionarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(524, 529);
            this.Controls.Add(this.cadastrarBtn);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.validadeCNHdateTimePicker);
            this.Controls.Add(this.cnhMaskedTB);
            this.Controls.Add(this.entregadorRadioBtn);
            this.Controls.Add(this.AtendenteRadioBtn);
            this.Controls.Add(this.adminRadioBtn);
            this.Controls.Add(this.senhaMaskedTB);
            this.Controls.Add(this.telefonemaskedTB);
            this.Controls.Add(this.cpfMaskedTB);
            this.Controls.Add(this.matriculaTB);
            this.Controls.Add(this.nomeTB);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "TelaCadastrarFuncionarios";
            this.Text = "TelaCadastrar";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox nomeTB;
        private System.Windows.Forms.TextBox matriculaTB;
        private System.Windows.Forms.MaskedTextBox cpfMaskedTB;
        private System.Windows.Forms.MaskedTextBox telefonemaskedTB;
        private System.Windows.Forms.MaskedTextBox senhaMaskedTB;
        private System.Windows.Forms.RadioButton adminRadioBtn;
        private System.Windows.Forms.RadioButton AtendenteRadioBtn;
        private System.Windows.Forms.RadioButton entregadorRadioBtn;
        private System.Windows.Forms.MaskedTextBox cnhMaskedTB;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.Button cadastrarBtn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker validadeCNHdateTimePicker;
    }
}