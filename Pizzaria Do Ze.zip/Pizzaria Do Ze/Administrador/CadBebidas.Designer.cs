﻿namespace Pizzaria_Do_Ze.Telas_Admin
{
    partial class CadBebidas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tipoTB = new System.Windows.Forms.TextBox();
            this.nomeTB = new System.Windows.Forms.TextBox();
            this.tamanhoTB = new System.Windows.Forms.TextBox();
            this.valorTB = new System.Windows.Forms.TextBox();
            this.bebidasListBox = new System.Windows.Forms.ListBox();
            this.cadastrarBtn = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.cancelbtn = new System.Windows.Forms.Button();
            this.labelbebidascadastradas = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(189, 82);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tipo: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(177, 33);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nome: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(156, 132);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tamanho:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(182, 182);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Valor: ";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // tipoTB
            // 
            this.tipoTB.Location = new System.Drawing.Point(254, 76);
            this.tipoTB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tipoTB.Name = "tipoTB";
            this.tipoTB.Size = new System.Drawing.Size(148, 26);
            this.tipoTB.TabIndex = 4;
            // 
            // nomeTB
            // 
            this.nomeTB.Location = new System.Drawing.Point(254, 33);
            this.nomeTB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.nomeTB.Name = "nomeTB";
            this.nomeTB.Size = new System.Drawing.Size(148, 26);
            this.nomeTB.TabIndex = 5;
            // 
            // tamanhoTB
            // 
            this.tamanhoTB.Location = new System.Drawing.Point(254, 126);
            this.tamanhoTB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tamanhoTB.Name = "tamanhoTB";
            this.tamanhoTB.Size = new System.Drawing.Size(148, 26);
            this.tamanhoTB.TabIndex = 6;
            // 
            // valorTB
            // 
            this.valorTB.Location = new System.Drawing.Point(254, 179);
            this.valorTB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.valorTB.Name = "valorTB";
            this.valorTB.Size = new System.Drawing.Size(148, 26);
            this.valorTB.TabIndex = 7;
            // 
            // bebidasListBox
            // 
            this.bebidasListBox.FormattingEnabled = true;
            this.bebidasListBox.ItemHeight = 20;
            this.bebidasListBox.Location = new System.Drawing.Point(101, 246);
            this.bebidasListBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bebidasListBox.Name = "bebidasListBox";
            this.bebidasListBox.Size = new System.Drawing.Size(456, 164);
            this.bebidasListBox.TabIndex = 8;
            // 
            // cadastrarBtn
            // 
            this.cadastrarBtn.Location = new System.Drawing.Point(512, 438);
            this.cadastrarBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cadastrarBtn.Name = "cadastrarBtn";
            this.cadastrarBtn.Size = new System.Drawing.Size(115, 36);
            this.cadastrarBtn.TabIndex = 9;
            this.cadastrarBtn.Text = "Cadastrar";
            this.cadastrarBtn.UseVisualStyleBackColor = true;
            this.cadastrarBtn.Click += new System.EventHandler(this.cadastrarBtn_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(385, 376);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(172, 34);
            this.button2.TabIndex = 10;
            this.button2.Text = "Excluir ";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // cancelbtn
            // 
            this.cancelbtn.Location = new System.Drawing.Point(399, 437);
            this.cancelbtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cancelbtn.Name = "cancelbtn";
            this.cancelbtn.Size = new System.Drawing.Size(105, 36);
            this.cancelbtn.TabIndex = 11;
            this.cancelbtn.Text = "Cancelar";
            this.cancelbtn.UseVisualStyleBackColor = true;
            // 
            // labelbebidascadastradas
            // 
            this.labelbebidascadastradas.AutoSize = true;
            this.labelbebidascadastradas.Location = new System.Drawing.Point(70, 221);
            this.labelbebidascadastradas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelbebidascadastradas.Name = "labelbebidascadastradas";
            this.labelbebidascadastradas.Size = new System.Drawing.Size(166, 20);
            this.labelbebidascadastradas.TabIndex = 12;
            this.labelbebidascadastradas.Text = "Bebidas Cadastradas:";
            // 
            // CadBebidas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(631, 475);
            this.Controls.Add(this.labelbebidascadastradas);
            this.Controls.Add(this.cancelbtn);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.cadastrarBtn);
            this.Controls.Add(this.bebidasListBox);
            this.Controls.Add(this.valorTB);
            this.Controls.Add(this.tamanhoTB);
            this.Controls.Add(this.nomeTB);
            this.Controls.Add(this.tipoTB);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "CadBebidas";
            this.Text = "Cadastrar Bebidas";
            this.Load += new System.EventHandler(this.TelaCadastrarBebidas_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tipoTB;
        private System.Windows.Forms.TextBox nomeTB;
        private System.Windows.Forms.TextBox tamanhoTB;
        private System.Windows.Forms.TextBox valorTB;
        private System.Windows.Forms.ListBox bebidasListBox;
        private System.Windows.Forms.Button cadastrarBtn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button cancelbtn;
        private System.Windows.Forms.Label labelbebidascadastradas;
    }
}