﻿namespace Pizzaria_Do_Ze
{
    partial class TelaPrincipalAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pizzaBtn = new System.Windows.Forms.Button();
            this.pedidoBtn = new System.Windows.Forms.Button();
            this.voltarBtn = new System.Windows.Forms.Button();
            this.visualizarPedidosBtn = new System.Windows.Forms.Button();
            this.cadastroFuncionarioBtn = new System.Windows.Forms.Button();
            this.editarStatusBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // pizzaBtn
            // 
            this.pizzaBtn.Location = new System.Drawing.Point(49, 51);
            this.pizzaBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pizzaBtn.Name = "pizzaBtn";
            this.pizzaBtn.Size = new System.Drawing.Size(283, 43);
            this.pizzaBtn.TabIndex = 0;
            this.pizzaBtn.Text = "Pizza";
            this.pizzaBtn.UseVisualStyleBackColor = true;
            this.pizzaBtn.Click += new System.EventHandler(this.pizzaBtn_Click);
            // 
            // pedidoBtn
            // 
            this.pedidoBtn.Location = new System.Drawing.Point(49, 215);
            this.pedidoBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pedidoBtn.Name = "pedidoBtn";
            this.pedidoBtn.Size = new System.Drawing.Size(283, 42);
            this.pedidoBtn.TabIndex = 5;
            this.pedidoBtn.Text = "Cadastro Pedido";
            this.pedidoBtn.UseVisualStyleBackColor = true;
            this.pedidoBtn.Click += new System.EventHandler(this.pedidoBtn_Click);
            // 
            // voltarBtn
            // 
            this.voltarBtn.Location = new System.Drawing.Point(312, 334);
            this.voltarBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.voltarBtn.Name = "voltarBtn";
            this.voltarBtn.Size = new System.Drawing.Size(118, 30);
            this.voltarBtn.TabIndex = 8;
            this.voltarBtn.Text = "Voltar";
            this.voltarBtn.UseVisualStyleBackColor = true;
            this.voltarBtn.Click += new System.EventHandler(this.voltarBtn_Click);
            // 
            // visualizarPedidosBtn
            // 
            this.visualizarPedidosBtn.Location = new System.Drawing.Point(49, 104);
            this.visualizarPedidosBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.visualizarPedidosBtn.Name = "visualizarPedidosBtn";
            this.visualizarPedidosBtn.Size = new System.Drawing.Size(283, 45);
            this.visualizarPedidosBtn.TabIndex = 9;
            this.visualizarPedidosBtn.Text = "Visualizar Pedidos";
            this.visualizarPedidosBtn.UseVisualStyleBackColor = true;
            this.visualizarPedidosBtn.Click += new System.EventHandler(this.visualizarPedidosBtn_Click);
            // 
            // cadastroFuncionarioBtn
            // 
            this.cadastroFuncionarioBtn.Location = new System.Drawing.Point(49, 267);
            this.cadastroFuncionarioBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cadastroFuncionarioBtn.Name = "cadastroFuncionarioBtn";
            this.cadastroFuncionarioBtn.Size = new System.Drawing.Size(283, 40);
            this.cadastroFuncionarioBtn.TabIndex = 10;
            this.cadastroFuncionarioBtn.Text = "Cadastro Funcionario";
            this.cadastroFuncionarioBtn.UseVisualStyleBackColor = true;
            this.cadastroFuncionarioBtn.Click += new System.EventHandler(this.cadastroFuncionarioBtn_Click);
            // 
            // editarStatusBtn
            // 
            this.editarStatusBtn.Location = new System.Drawing.Point(49, 159);
            this.editarStatusBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.editarStatusBtn.Name = "editarStatusBtn";
            this.editarStatusBtn.Size = new System.Drawing.Size(283, 46);
            this.editarStatusBtn.TabIndex = 11;
            this.editarStatusBtn.Text = "Editar o status do pedido";
            this.editarStatusBtn.UseVisualStyleBackColor = true;
            this.editarStatusBtn.Click += new System.EventHandler(this.editarStatusBtn_Click);
            // 
            // TelaPrincipalAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(441, 372);
            this.Controls.Add(this.editarStatusBtn);
            this.Controls.Add(this.cadastroFuncionarioBtn);
            this.Controls.Add(this.visualizarPedidosBtn);
            this.Controls.Add(this.voltarBtn);
            this.Controls.Add(this.pedidoBtn);
            this.Controls.Add(this.pizzaBtn);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "TelaPrincipalAdmin";
            this.Text = "Principal Administrador";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button pizzaBtn;
        private System.Windows.Forms.Button pedidoBtn;
        private System.Windows.Forms.Button voltarBtn;
        private System.Windows.Forms.Button visualizarPedidosBtn;
        private System.Windows.Forms.Button cadastroFuncionarioBtn;
        private System.Windows.Forms.Button editarStatusBtn;
    }
}